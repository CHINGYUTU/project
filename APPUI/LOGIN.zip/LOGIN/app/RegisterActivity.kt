import android.animation.ObjectAnimator
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.ImageView
import android.widget.EditText
import android.widget.Button
import com.example.login.R

class RegisterActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val logo: ImageView = findViewById(R.id.logo)
        val name: EditText = findViewById(R.id.name)
        val account: EditText = findViewById(R.id.account)
        val password: EditText = findViewById(R.id.password)
        val email: EditText = findViewById(R.id.email)
        val registerButton: Button = findViewById(R.id.register_button)

        // 設置 logo 動畫
        val animator = ObjectAnimator.ofFloat(logo, "translationY", -200f, 0f)
        animator.duration = 1000
        animator.interpolator = AccelerateDecelerateInterpolator()
        animator.start()

        // 設置其他控件漸變動畫
        val views = listOf(name, account, password, email, registerButton)
        views.forEachIndexed { index, view ->
            view.alpha = 0f
            view.animate()
                .alpha(1f)
                .setStartDelay((index * 300).toLong())
                .duration = 800
            view.animate().interpolator = AccelerateDecelerateInterpolator()
            view.animate().start()
        }
    }
}