package com.example.coffeeshop.domain.model

data class CoffeeCategory(
    val id:String,
    val title:String
)