package com.example.coffeeshop

expect fun logInTerminal(data:String)