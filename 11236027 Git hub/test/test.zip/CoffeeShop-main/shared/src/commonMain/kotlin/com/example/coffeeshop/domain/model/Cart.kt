package com.example.coffeeshop.domain.model

data class Cart(
    val products:List<Coffee>
)