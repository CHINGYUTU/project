package com.example.coffeeshop.domain.model

class Location(
    val name:String,
    val latitude:Double,
    val longitude:Double
)