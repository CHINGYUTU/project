package com.example.coffeeshop.data.network.model

import kotlinx.serialization.Serializable

@Serializable
data class SessionDto(
    val session:String
)