package com.example.coffeeshop.domain.model

class Payment(
    val products:List<Coffee>,
    val price:Float
)