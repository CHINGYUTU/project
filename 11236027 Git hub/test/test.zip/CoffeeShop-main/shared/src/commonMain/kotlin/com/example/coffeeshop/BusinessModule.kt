package com.example.coffeeshop

expect class BusinessModule {
     fun init()
}