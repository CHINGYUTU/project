package com.example.coffeeshop.data.model

data class DataCart(
    val products:String
)