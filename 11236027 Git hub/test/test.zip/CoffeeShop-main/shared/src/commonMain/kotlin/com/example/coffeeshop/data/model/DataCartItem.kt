package com.example.coffeeshop.data.model

data class DataCartItem(
    val id:Long?,
    var amount:Int,
    val productId:String
)