package com.example.coffeeshop

actual fun logInTerminal(data:String){

}