package com.example.coffeeshop

import android.util.Log

actual fun logInTerminal(data: String) {
    Log.d("dddfcccccc", data)
}