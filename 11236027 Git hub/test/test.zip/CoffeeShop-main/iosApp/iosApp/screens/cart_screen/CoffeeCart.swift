//
//  CoffeeCart.swift
//  iosApp
//
//  Created by MacBook on 20.12.2023.
//  Copyright © 2023 orgName. All rights reserved.
//

import SwiftUI
import shared

struct CoffeeCart{
    
    let coffee:Coffee?
    var amount:Int
    
}
