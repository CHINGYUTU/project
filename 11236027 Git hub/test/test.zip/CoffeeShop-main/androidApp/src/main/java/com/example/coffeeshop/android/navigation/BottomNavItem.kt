package com.example.coffeeshop.android.navigation

class BottomNavItem(
    val icon: Int,
    val name:String,
    val route:String
)