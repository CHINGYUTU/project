package com.example.coffeeshop.android.screen.favorite_coffee_screen

data class SearchCoffeeUIState(
    val searchMode:Boolean = false,
    val symbols:String = ""
)