package com.example.coffeeshop.android.screen.main_screen

data class SearchCoffeeUIState(
    val searchMode:Boolean = false,
    val symbols:String = ""
)